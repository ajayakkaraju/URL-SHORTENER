# AI Usage Notes

- Tool used: GitHub Copilot (AI assistant)
- Used for: Generating code for all endpoints, models, utilities, and tests as per assignment requirements.
- All code was reviewed and adapted for correctness and clarity.
- No code was copied from external sources; all logic was generated and customized for this assignment.
